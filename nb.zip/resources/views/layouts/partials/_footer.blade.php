@section('footer')
<footer class="footer-global" id="big-footer">
    <div class="container-fluid">
        <div class="footer-below text-center">
            <div class="row">
                <div class="col-sm-12">
                    <p>&copy; Masenoboards</p>
                </div> <!-- /.col-lg-12 -->
            </div> <!-- /.row -->
        </div> <!-- /.footer-below text-center -->
    </div> <!-- /.container-fluid -->
</footer> <!-- /.footer-global -->
@show
