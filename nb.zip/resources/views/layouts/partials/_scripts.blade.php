<!-- jQuery -->
<script src="{!! URL::to('js/jquery-3.2.1.min.js') !!}"></script>

<!-- Tether JS -->
<script src="{!! URL::to('js/tether.min.js') !!}"></script>

<!-- Bootstrap JS-->
<script src="{!! URL::to('js/bootstrap.min.js') !!}"></script>

<!-- Universal Custom JavaScript -->
<script src="{!! URL::to('js/custom.js') !!}"></script>
<!-- Custom Javascript -->
@yield('scripts')
