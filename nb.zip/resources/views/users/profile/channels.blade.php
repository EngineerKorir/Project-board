@extends('layouts.partials._dashboard')
@section('dashboard-title')
Channels subscribed by Lana
@endsection
@section('dashboard-header')
@endsection
@section('dashboard-content')
<div class="row">
	<div class="col">
		<main>
			<section id="profile-channels">
				<div class="card">
					<div class="card-header"><i class="fa fa-clipboard mr-2"></i>Channels subscribed by Lana</div>
					<div class="card-block p-1 text-center">
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
						<div class="subscribers-box">
							<img src="https://pbs.twimg.com/profile_images/1610379352/Maseno_University_Official_avatar.png" alt="Maseno University" title="Maseno University" class="img-fluid small-img center-block">
							<strong><a href="#">Computer Science</a></strong><br>
							345 Subscribers<br>
						</div>
					</div>
				</div> <!-- /.card -->
			</section> <!-- /#profile-channels -->
		</main>
	</div> <!-- /.col -->
</div><!-- /.row -->
@endsection
