<html>
<head></head>
<body style="background: #2B547E; color: #fff; padding: 5px;">
<h1>{!! $title !!}</h1>
<p>{!! $content !!}</p>
</body>
</html>
