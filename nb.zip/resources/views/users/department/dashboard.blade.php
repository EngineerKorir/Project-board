@extends('layouts.partials._dashboard')

@section('dashboard-title')
	Dashboard
@endsection

@section('dashboard-header')
@endsection

@section('breadcrumb')
	<li class="breadcrumb-item active">Department home</li>
@endsection

@section('dashboard-content')
<div class="row">
	<div class="col">
		<main>
			<section id="profile-edit">
				<div class="card">
					<div class="card-header"><i class="fa fa-clipboard mr-2"></i>Dashboard</div>
					<div class="card-block">

					</div>
				</div> <!-- /.card -->
			</section>
		</main>
	</div> <!-- /.col -->
</div> <!-- /.row -->
@endsection
