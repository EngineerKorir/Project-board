<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LikeShare extends Model
{
    protected $table = 'like_shares';
}
