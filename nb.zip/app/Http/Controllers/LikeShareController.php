<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LikeShareController extends Controller
{
    //
}
