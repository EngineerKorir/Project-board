<?php $__env->startSection('header-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard-title'); ?>
New notice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard-header'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo route('getLecturerDashboard'); ?>" title="Lecturer home">Lecturer home</a></li>
<li class="breadcrumb-item active">New notice</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="row">
	<div class="col-md-9">
		<main>
			<section id="notices-new">
						<form class="" action="<?php echo route('postLecturerNewNotice'); ?>" method="POST" data-parsley-validate="" enctype="multipart/form-data">

							<?php echo e(csrf_field()); ?>


							<div class="form-group <?php echo e($errors->has('title') ? 'has-warning' : ''); ?>">
								<label for="title" class="text-muted font-size-xs">Title</label>

								<input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" placeholder="Title*" required="">

								<?php if($errors->has('title')): ?>
                <small class="form-text text-danger">
                  <?php echo e($errors->first('title')); ?>

                </small>
                <?php endif; ?>
							</div>

							<div class="form-group <?php echo e($errors->has('body') ? 'has-warning' : ''); ?>">
								<label for="body" class="text-muted font-size-xs">Body</label>

								<textarea name="body" id="body-wyg" rows="14" class="form-control" required=""><?php echo e(old('body')); ?></textarea>

								<?php if($errors->has('body')): ?>
                <small class="form-text text-danger">
                  <?php echo e($errors->first('body')); ?>

                </small>
                <?php endif; ?>
							</div>

							<div class="row">
								<div class="col mt-1">
									<label for="deadline" class="text-muted font-size-xs">Deadline (Optional, default 14 days)</label>

									<input type="text" name="deadline" value="<?php echo e(old('deadline')); ?>" class="datepicker-here form-control" data-position="top left" data-language='en' data-timepicker="true" placeholder="Deadline">

									<?php if($errors->has('deadline')): ?>
	                <small class="form-text text-danger">
	                  <?php echo e($errors->first('deadline')); ?>

	                </small>
	                <?php endif; ?>
								</div>
							</div>

							<div class="row mt-3">
								<div class="col mt-1">
									<label for="files" class="text-muted font-size-xs">Upload multiple files</label>
									<input type="file" name="files[]" class="form-control-file" id="files" multiple="">

									<?php if($errors->has('files')): ?>
	                <small class="form-text text-danger">
	                  <?php echo e($errors->first('files')); ?>

	                </small>
	                <?php endif; ?>
								</div>
							</div>



				</section>
			</main>
		</div> <!-- /.col-md-9 -->

		<div class="col-md-3">
			<aside>
				<section id="notices-new-aside">
					<div class="card">
						<div class="card-header bb-0">Notice category</div>
						<div class="card-block pr-1">

							<?php if($categories->isEmpty()): ?>

			        <p class="text-center pt-5 pb-5">You have not created any categories.</p>

			        <?php else: ?>

							<div class="scroll-div">
								<div class="custom-controls-stacked">

									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<label class="custom-control custom-checkbox ml-2">
										<input type="checkbox" name="category_id[]" value="<?php echo e($category->id); ?>" class="custom-control-input">
										<span class="custom-control-indicator"></span>
										<span class="custom-control-description"><?php echo e($category->title); ?></span>
									</label>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</div> <!-- /.custom-controls-stacked -->
							</div> <!-- /.scroll-div -->

							<?php endif; ?>

						</div>
					</div>

					<div class="card mt-3">
						<div class="card-header bb-0">Student year</div>
						<div class="card-block pr-1">
							<div class="scroll-div">

								<div class="custom-controls-stacked">

									<?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<label class="custom-control custom-checkbox ml-2">
										<input type="checkbox" name="target_id[year][]" value="<?php echo e($year->id); ?>" class="custom-control-input">
										<span class="custom-control-indicator"></span>
										<span class="custom-control-description"><?php echo e($year->name); ?></span>
									</label>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</div> <!-- /.custom-controls-stacked -->
							</div> <!-- /.scroll-div -->
						</div>
					</div>

					<div class="card mt-3">
						<div class="card-header bb-0">Student department</div>
						<div class="card-block pr-1">
							<div class="scroll-div">
								<div class="custom-controls-stacked">

									<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<label class="custom-control custom-checkbox ml-2">
										<input type="checkbox" name="target_id[department][]" value="<?php echo e($department->id); ?>" class="custom-control-input">
										<span class="custom-control-indicator"></span>
										<span class="custom-control-description"><?php echo e($department->name); ?></span>
									</label>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</div> <!-- /.custom-controls-stacked -->
							</div> <!-- /.scroll-div -->
						</div>
					</div>

					<label class="custom-control custom-checkbox ml-2 mt-3 font-size-xs">
						<input type="checkbox" name="strict" value="strict" class="custom-control-input">
						<span class="custom-control-indicator"></span>
						<span class="custom-control-description">Strict. Notice visible by selected users only</span>
					</label>

					<button type="submit" name="submit" class="btn btn-primary btn-sm mt-5" value="1" title="Publish">Publish</button>

					<button type="submit" name="submit" class="btn btn-outline-info btn-sm mt-5 ml-2 mr-2" value="2" title="Draft">Draft</button>

					<button type="button" name="trash" class="btn btn-outline-info btn-sm mt-5" title="Trash">Trash</button>

				</form>
			</section>
		</aside>
	</div> <!-- /.col-md-3 -->
</div> <!-- .row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo URL::to('js/trumbowyg.min.js'); ?>"></script>
<script src="<?php echo URL::to('js/datepicker.min.js'); ?>"></script>
<!-- Include English language -->
<script src="<?php echo URL::to('js/i18n/datepicker.en.js'); ?>"></script>
<script src="<?php echo URL::to('js/parsley.min.js'); ?>"></script>

<script>

// Initialize Trumbowyg

$('textarea').trumbowyg({
    btns: [
        ['formatting'],
        'btnGrp-semantic',
        ['link'],
        ['insertImage'],
        'btnGrp-justify',
        'btnGrp-lists',
        ['horizontalRule'],
        ['removeformat'],
        ['fullscreen']
    ]
});

// restrict date selection

$('.datepicker-here').datepicker({
    language: 'en',
    minDate: new Date() // Now can select only dates, which goes after today
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials._dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>