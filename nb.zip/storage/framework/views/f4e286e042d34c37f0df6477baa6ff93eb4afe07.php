<?php if($notice): ?>

<footer>
  <div class="hmi-author">
    <p class="font-size-xs"><a href="#">

      <?php if($notice->user): ?>
      <?php if($notice->user->role_id == 2): ?> 

      <?php echo $notice->user->department->name .' '.$notice->user->username; ?>


      <?php elseif($notice->user->role_id == 4 && $notice->user->salutation_id != 0): ?> 

      <?php echo $notice->user->salutation->name .'. '. $notice->user->username; ?>


      <?php else: ?> 

      <?php echo $notice->user->username; ?>


      <?php endif; ?>
      <?php endif; ?>

    </a>
      <i class="fa fa-clock-o glyph-r-margin glyph-l-margin"></i><?php echo e($notice->created_at); ?>

      <i class="fa fa-eye glyph-r-margin glyph-l-margin"></i> <?php echo e($notice->views); ?> views

      <?php if($notice->deadline): ?>
      <i class="fa fa-warning glyph-r-margin glyph-l-margin text-warning"></i>Deadline <?php echo e($notice->deadline); ?>

      <?php endif; ?>

    </p>
  </div>
</footer>

<?php endif; ?>
