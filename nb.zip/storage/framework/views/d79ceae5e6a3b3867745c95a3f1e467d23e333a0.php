<?php $__env->startSection('dashboard-title'); ?>
My subscribers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo route('getStudentDashboard'); ?>" title="Student home">Student home</a></li>
<li class="breadcrumb-item active">My subscribers</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="row">
	<div class="col">
		<main>
			<section id="profile-myChannels">

				<div class="card">
					<div class="card-header bb-0">My subscribers</div>
					<div class="card-block text-center p-1">

						<?php if($subscribers->isEmpty()): ?>

						<p class="text-center pt-5 pb-5">You do not have any subscribers yet.</p>

						<?php else: ?>
							<?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="subscribers-box m-2 mb-5 pt-3">
								<?php if($channel->photo): ?>
								<img src="<?php echo e(URL::to('images/avatars/medium/' . $channel->photo)); ?>" alt="Avatar" class="img-fluid small-img center-block">

								<?php else: ?>

								<img src="<?php echo e(URL::to('images/avatars/default/medium/avatar.png')); ?>" class="img-fluid small-img center-block">

								<?php endif; ?>

								<?php if($channel->role_id === 2): ?>

								<a href="#" class="d-block text-overflow"><?php echo e($channel->department->name); ?> - <?php echo e($channel->username); ?></a>
								<span class="badge badge-pill badge-info mt-2 mb-2">Department</span>

								<?php else: ?>

								<a class="d-block text-overflow" href="#"><?php echo e($channel->username); ?></a>

								<?php if($channel->role_id === 1): ?>
								<span class="badge badge-pill badge-info mt-2 mb-2">Student</span>

								<?php elseif($channel->role_id === 3): ?>
								<span class="badge badge-pill badge-info mt-2 mb-2">Organization</span>

								<?php elseif($channel->role_id === 4): ?>
								<span class="badge badge-pill badge-info mt-2 mb-2">Lecturer</span>

								<?php else: ?>
								<span class="badge badge-pill badge-info mt-2 mb-2">Class rep</span>
								<?php endif; ?>

								<?php endif; ?>

								<div><?php echo e($totalSubscribers[$channel->id]); ?> subscribers</div>

								<form class="" action="<?php echo e(route('postBlock', ['id' => $channel->id ])); ?>" method="POST" id="postBlock-<?php echo e($channel->id); ?>">
									<?php echo e(csrf_field()); ?>


									<?php if($isBlocked[$channel->id]): ?>
									<input type="submit" name="submit" value="Unblock" class="btn btn-danger btn-sm mt-2 mb-2">
									<?php else: ?>
									<input type="submit" name="submit" value="Block" class="btn btn-primary btn-sm mt-2 mb-2">
									<?php endif; ?>
								</form>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>

					</div>
				</div><!-- /.card -->
			</section>
		</main>
	</div> <!-- /.col -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials._dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>