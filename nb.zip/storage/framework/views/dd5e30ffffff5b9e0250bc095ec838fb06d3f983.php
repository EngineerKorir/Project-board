<div class="row">
  <div class="col pb-3">
    <div class="dropdown">
      <button class="btn btn-secondary btn-sm borderless-btn dropdown-toggle" type="button" id="selector" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Activity
      </button>
      <div class="dropdown-menu" aria-labelledby="selector">
        <a class="dropdown-item" href="#">Subscribed Channels</a>
        <a class="dropdown-item" href="#">Computer Science</a>
        <a class="dropdown-item" href="#">Year three</a>
        <a class="dropdown-item" href="#">Caroline Herine</a>
        <a class="dropdown-item" href="#">Comrades</a>
      </div>
    </div>
  </div>
</div>
