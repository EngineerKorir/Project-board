<?php $__env->startSection('content'); ?>
<div class="cover mb-2">
	<div class="text">
		<h1 class="h4">The Easiest Way To Be Updated</h1>
		<p class="lead">Connect with Maseno University departments, organizations and more.</p>
		<span class="actions"><a href="<?php echo e(route('getRegister')); ?>" class="btn btn-primary glyph-r-margin">Register</a> or <a href="<?php echo e(route('getLogin')); ?>" class="link glyph-l-margin">Sign in</a></span>
	</div>
</div><!-- /.cover -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>