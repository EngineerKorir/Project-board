<?php $__env->startSection('dashboard-title'); ?>
Subscribers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo route('getOrganizationDashboard'); ?>" title="Organization home">Organization home</a></li>
<li class="breadcrumb-item active">Subscribers</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="row">
	<div class="col">
		<main>
			<section id="notices-subscribers">
				<div class="card">
					<div class="card-header"><i class="fa fa-users mr-2"></i>Subscribers</div>
					<div class="card-block p-0 pt-3 text-center">
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
						<div class="subscribers-box">
							<img src="http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg" alt="Lana" title="Lana" class="img-fluid center-block">
							<strong><a href="#">Lana Achieng</a></strong><br>
							Computer Science
						</div>
					</div>
				</div> <!-- /.card -->
			</section>
		</main>
	</div> <!-- /.col -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials._dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>