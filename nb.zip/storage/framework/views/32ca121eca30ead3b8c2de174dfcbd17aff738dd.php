<?php $__env->startSection('dashboard-title'); ?>
Subscribers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo route('getLecturerDashboard'); ?>" title="Lecturer home">Lecturer home</a></li>
<li class="breadcrumb-item active">Subscribers</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="row">
	<div class="col">
		<main>
			<section id="notices-subscribers">
				<div class="card">
					<div class="card-header bb-0">Subscribers</div>
					<div class="card-block p-0 pt-3 text-center">

						<?php if($subscribers->isEmpty()): ?>

		        <p class="text-center pt-5 pb-5">You do not have any subscribers yet.</p>

		        <?php else: ?>

						<?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<div class="subscribers-box">
							<?php if($subscriber->photo): ?>
							<img src="<?php echo e(URL::to('images/avatars/medium/' . $subscriber->photo)); ?>" alt="Avatar" class="img-fluid center-block" width="250">

							<?php else: ?>

							<img src="<?php echo e(URL::to('images/avatars/default/medium/avatar.png')); ?>" class="img-fluid center-block">

							<?php endif; ?>

							<strong><a href="#" title="<?php echo e($subscriber->username); ?>"><?php echo e($subscriber->username); ?></a></strong><br>
							<?php echo e($subscriber->department->name); ?>

						</div>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php endif; ?>
					</div>
				</div> <!-- /.card -->
			</section>
		</main>
	</div> <!-- /.col -->
</div> <!-- /.row -->
<div class="row">
	<div class="col p-5 text-center">
		<?php echo $subscribers->links(); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials._dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>