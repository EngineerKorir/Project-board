<?php $__env->startSection('dashboard-title'); ?>
All activity
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard-header'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dashboard-content'); ?>
<div class="row">
	<div class="col-md-9">
		<main>
			<section id="notice-view">

				<div class="row">
				  <div class="col pb-3">

						<?php if(in_array($user->role_id, ['1','5'])): ?> 

				    <div class="dropdown">
				      <button class="btn btn-secondary btn-sm borderless-btn dropdown-toggle" type="button" id="selector" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				        <strong>Categories</strong>
				      </button>
				      <div class="dropdown-menu" aria-labelledby="selector">
				        <a class="dropdown-item <?php echo e(isset($subscribedChannels) ? 'active' : ''); ?>" href="<?php echo e(route('getHome')); ?>">Subscribed Channels</a>
				        <a class="dropdown-item <?php echo e(isset($myDepartment) ? 'active' : ''); ?>" href="<?php echo e(route('getHomeDepartment')); ?>">Department</a>
				      </div>
				    </div>

						<?php endif; ?>

				  </div>
				</div>

				<?php if($notices->isEmpty()): ?>

        <p class="text-center pt-5 pb-5">There are no annoucements yet.</p>

        <?php else: ?>

        <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card mb-5">
					<div class="card-header pt-3 bb-0">
						<h6>
							<a href="<?php echo e(route('getShowNotice', ['id' => $notice->id, 'slug' => $notice->slug])); ?>" title="<?php echo e($notice->title); ?>"><?php echo e($notice->title); ?></a>
						</h6>
					</div>
					<div class="card-block">
						<?php echo $__env->make('layouts.partials.footers._author', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php echo $notice->body; ?>

					</div>
					<div class="card-footer bg-white pt-0 pb-0 bt-0">
						<?php echo $__env->make('layouts.partials.footers._share-home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>

        <div class="text-center">
          <?php echo $notices->links(); ?>

        </div>

			</section>
		</main>

	</div> <!-- /.col-md-9 -->
	<div class="col-md-3">
		<aside>
			<section id="notice-view-sidebar">
				<div class="notice-sidebar">


				</div><!-- /.notice-sidebar -->
			</section>
		</aside>
	</div> <!-- /.col-md-3 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials._dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>