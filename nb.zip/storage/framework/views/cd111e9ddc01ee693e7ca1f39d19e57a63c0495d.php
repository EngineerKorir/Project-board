<?php if($user): ?>
<li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle" href="#" id="notices" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

    <span class="menu-avatar">
      <?php if($user->photo): ?>
      <img src="<?php echo e(URL::to('images/avatars/small/' . $user->photo)); ?>" alt="<?php echo e($user->username); ?>" title="<?php echo e($user->username); ?>" class="img-fluid">

      <?php else: ?>

      <img src="<?php echo e(URL::to('images/avatars/default/small/avatar.png')); ?>" alt="<?php echo e($user->username); ?>" title="<?php echo e($user->username); ?>" class="img-fluid">

      <?php endif; ?>
    </span>

    <?php if($user->role_id === 1): ?> 

    <?php echo $user->username; ?>


    <?php elseif($user->role_id === 2): ?> 

    <?php echo $user->department->name .' '.$user->username; ?>


    <?php elseif($user->role_id === 4 && $user->salutation_id !== 0): ?> 

    <?php echo $user->salutation->name .'. '. $user->username; ?>


    <?php else: ?>

    <?php echo $user->username; ?>


    <?php endif; ?>

  </a>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="<?php echo e(route('getLogout')); ?>">Logout</a>
  </div>
</li>
<?php endif; ?>
