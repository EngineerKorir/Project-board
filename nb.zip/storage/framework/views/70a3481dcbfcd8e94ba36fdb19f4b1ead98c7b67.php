<!DOCTYPE html>
<html lang="en-US">
<head>
	<?php echo $__env->make('layouts.partials._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
	<!-- Navigation -->
	<?php echo $__env->make('layouts.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- Main Content -->
	<?php echo $__env->yieldContent('content'); ?>

	<!-- Footer -->
	<?php echo $__env->make('layouts.partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- Javascripts -->
	<?php echo $__env->make('layouts.partials._scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
