<?php $__env->startSection('dashboard-title'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active">Dashboard</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-content'); ?>
<main>
  <section id="notices-dashboard">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        <div class="dash-box bg-info">
          <div class="inner">
            <h3>34</h3>
            <p>Notices</p>
          </div>
          <div class="dash-box-icon">
            <i class="fa fa-clipboard"></i>
          </div>
          <div class="dash-box-footer">
            <a href="/notices/all">View notices</a> <i class="fa fa-arrow-right"></i>
          </div>
        </div>
      </div>

      <div class="col-md-3 col-sm-6">
        <div class="dash-box bg-warning">
          <div class="inner">
            <h3>2</h3>
            <p>New messages</p>
          </div>
          <div class="dash-box-icon">
            <i class="fa fa-envelope"></i>
          </div>
          <div class="dash-box-footer">
            <a href="/notices/messages">View messages</a> <i class="fa fa-arrow-right"></i>
          </div>
        </div>
      </div>

      <div class="col-md-3 col-sm-6">
        <div class="dash-box bg-success">
          <div class="inner">
            <h3>8</h3>
            <p>New comments</p>
          </div>
          <div class="dash-box-icon">
            <i class="fa fa-comment-o"></i>
          </div>
          <div class="dash-box-footer">
            <a href="/notices/comments">View comments</a> <i class="fa fa-arrow-right"></i>
          </div>
        </div>
      </div>

      <div class="col-md-3 col-sm-6">
        <div class="dash-box bg-danger">
          <div class="inner">
            <h3>780</h3>
            <p>Subscribers</p>
          </div>
          <div class="dash-box-icon">
            <i class="fa fa-user"></i>
          </div>
          <div class="dash-box-footer">
            <a href="/notices/subscribers">View subscribers</a> <i class="fa fa-arrow-right"></i>
          </div>
        </div>
      </div>
    </div> <!-- /.row -->
  </section> <!-- /#notices-dashboard -->
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials._dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>