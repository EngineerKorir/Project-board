<nav class="navbar navbar-toggleable-sm navbar-light fixed-top bg-faded navbar-full">
  <div class="navbar-header">
    <div id="burger-container" data-toggle="collapse" data-target="#responsive-navbar-collapse" class="hidden-md-up">
      <div id="burger">
        <span>&nbsp;</span>
        <span>&nbsp;</span>
        <span>&nbsp;</span>
      </div><!-- /.burger -->
    </div> <!-- /.burger-container -->
    <a class="navbar-brand" href="/">Masenoboards</a>
  </div> <!-- /.navbar-header -->

  <div class="navbar-collapse collapse" id="responsive-navbar-collapse">
    <ul class="navbar-nav">

      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('getHome')); ?>">Home</a></li>

      <?php if($user): ?>

      <?php if($user->role_id === 1): ?> 

      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('getStudentDashboard')); ?>" title="Student dashboard">Student</a></li>

      <?php elseif($user->role_id === 2): ?> 

      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('getDepartmentDashboard')); ?>" title="Department dashboard">Department</a></li>

      <?php elseif($user->role_id === 3): ?> 

      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('getOrganizationDashboard')); ?>" title="Organization dashboard">Organization</a></li>

      <?php elseif($user->role_id === 4): ?> 

      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('getLecturerDashboard')); ?>" title="Lecturer dashboard">Lecturer</a></li>

      <?php elseif($user->role_id === 5): ?> 

      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('getClassRepDashboard')); ?>" title="Class rep dashboard">Class rep</a></li>

      <?php else: ?>
      
      <?php endif; ?>

      <?php endif; ?>


    </ul>

    <!-- User Account Menu -->
    <ul class="navbar-nav ml-auto mr-5">
      <?php echo $__env->make('layouts.partials._nav_account', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </ul>
  </div>
</nav>
