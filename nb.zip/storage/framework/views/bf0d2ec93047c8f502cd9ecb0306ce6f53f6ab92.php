<footer class="simple-footer p-2">
	 Masenoboards
</footer>
