<?php $__env->startSection('dashboard-title'); ?>
My followers
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard-header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="/profile/view" title="My profile">Profile</a></li>
<li class="breadcrumb-item active">My followers</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard-content'); ?>
<div class="row">
	<div class="col">
		<main>
			<section id="profile-myFollowers" class="text-center">
				<div class="subscribers-box">
					<?php echo e(Html::image('http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg', 'Lana', ['class' => 'img-fluid small-img'])); ?>

					<strong><a href="#">Lana Achieng</a></strong><br>
					Computer Science<br>
					<?php echo e(Form::open(['url' => 'foo/bar'])); ?>

					<?php echo e(Form::button('Block', ['type' => 'submit', 'class' => 'btn btn-primary btn-sm mt-2'])); ?>

					<?php echo e(Form::close()); ?>

				</div>
				<div class="subscribers-box">
					<?php echo e(Html::image('http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg', 'Lana', ['class' => 'img-fluid small-img'])); ?>

					<strong><a href="#">Lana Achieng</a></strong><br>
					Computer Science<br>
					<?php echo e(Form::open(['url' => 'foo/bar'])); ?>

					<?php echo e(Form::button('Block', ['type' => 'submit', 'class' => 'btn btn-primary btn-sm mt-2'])); ?>

					<?php echo e(Form::close()); ?>

				</div>
				<div class="subscribers-box">
					<?php echo e(Html::image('http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg', 'Lana', ['class' => 'img-fluid small-img'])); ?>

					<strong><a href="#">Lana Achieng</a></strong><br>
					Computer Science<br>
					<?php echo e(Form::open(['url' => 'foo/bar'])); ?>

					<?php echo e(Form::button('Block', ['type' => 'submit', 'class' => 'btn btn-primary btn-sm mt-2'])); ?>

					<?php echo e(Form::close()); ?>

				</div>
				<div class="subscribers-box">
					<?php echo e(Html::image('http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg', 'Lana', ['class' => 'img-fluid small-img'])); ?>

					<strong><a href="#">Lana Achieng</a></strong><br>
					Computer Science<br>
					<?php echo e(Form::open(['url' => 'foo/bar'])); ?>

					<?php echo e(Form::button('Block', ['type' => 'submit', 'class' => 'btn btn-primary btn-sm mt-2'])); ?>

					<?php echo e(Form::close()); ?>

				</div>
				<div class="subscribers-box">
					<?php echo e(Html::image('http://oka-cdn.okayplayer.com/wp-content/uploads/NYFW-Model-to-Watch-Mari-Agory.jpg', 'Lana', ['class' => 'img-fluid small-img'])); ?>

					<strong><a href="#">Lana Achieng</a></strong><br>
					Computer Science<br>
					<?php echo e(Form::open(['url' => 'foo/bar'])); ?>

					<?php echo e(Form::button('Block', ['type' => 'submit', 'class' => 'btn btn-primary btn-sm mt-2'])); ?>

					<?php echo e(Form::close()); ?>

				</div>
			</section>
		</main>
	</div> <!-- /.col -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials._dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>