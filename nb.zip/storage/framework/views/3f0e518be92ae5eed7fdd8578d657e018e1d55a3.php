<section>
  <div class="btn-group btn-group-sm" role="group" aria-label="Button group with nested dropdown">


    <form class="" action="<?php echo e(route('postCommentLike', ['noticeId' =>$notice->id, 'commentId' => $comment->id])); ?>" method="POST" id="postCommentLike-<?php echo e($comment->id); ?>">
      <?php echo e(csrf_field()); ?>

    </form>

    <button onclick="document.getElementById('postCommentLike-<?php echo e($comment->id); ?>').submit();" class="btn btn-secondary borderless-btn btn-sm" title="Like"><i class="

    <?php if($isLike[$comment->id] === 1): ?>
      fa fa-heart text-info
    <?php else: ?>
        fa fa-heart
    <?php endif; ?>
      glyph-r-margin


    "></i><?php echo e($likeShareComment[$comment->id]['like']); ?></button>

    <div class="btn-group btn-group-sm" role="group">

      <button id="btnGroupDrop1" type="button" class="btn btn-secondary borderless-btn btn-sm dropdown-toggle text-muted" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="Share">
        <i class="fa fa-share-alt glyph-r-margin text-muted"></i><?php echo e($likeShareComment[$comment->id]['share']); ?>

      </button>

      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="btnGroupDrop1">

        <form class="" action="<?php echo e(route('postNoticeCommentShare', ['id' => $comment->id, 'to' => 'whatsapp'])); ?>" method="POST" id="postNoticeCommentShareWhatsapp-<?php echo e($comment->id); ?>">
          <?php echo e(csrf_field()); ?>

        </form>

        <form class="" action="<?php echo e(route('postNoticeCommentShare', ['id' => $comment->id, 'to' => 'timeline'])); ?>" method="POST" id="postNoticeCommentShareTimeline-<?php echo e($comment->id); ?>">
          <?php echo e(csrf_field()); ?>

        </form>

        <a onclick="document.getElementById('postNoticeCommentShareWhatsapp-<?php echo e($comment->id); ?>').submit();" class="dropdown-item" href="#"><i class="fa fa-whatsapp glyph-r-margin"></i>WhatsApp</a>

        <a onclick="document.getElementById('postNoticeCommentShareTimeline-<?php echo e($comment->id); ?>').submit();" class="dropdown-item" href="#"><i class="fa fa-user glyph-r-margin"></i>Timeline</a>
      </div>
    </div>
  </div>
</section>
