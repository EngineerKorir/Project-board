<?php $__env->startSection('content'); ?>

<main>
  <section id="login">
    <div class="container">
      <div class="row d-flex justify-content-center">
        <div class="col-lg-7">

          
          <?php echo $__env->make('layouts.partials._alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
          <div class="login-header-box">
            <h5>Sign in to Masenoboards</h5>
          </div>
          <div class="login-content p-4 pt-md-5">

            <form class="" action="<?php echo route('postLogin'); ?>" method="POST" data-parsley-validate="">

              <?php echo e(csrf_field()); ?>


              <div class="form-group <?php echo e($errors->has('email') ? 'has-warning' : ''); ?>">
                <label for="email" class="text-muted font-size-xs">Email</label>

                <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Email address*" required="">

                <div class="form-control-feedback"></div>

                <?php if($errors->has('email')): ?>
                <small class="form-text text-danger">
                  <?php echo e($errors->first('email')); ?>

                </small>
                <?php endif; ?>

              </div>

              <div class="form-group <?php echo e($errors->has('password') ? 'has-warning' : ''); ?>">
                <label for="password" class="text-muted font-size-xs">Password</label>

                <input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control" placeholder="Password*" required="">

                <?php if($errors->has('password')): ?>
                <small class="form-text text-danger">
                  <?php echo e($errors->first('password')); ?>

                </small>
                <?php endif; ?>

              </div>

              <input type="submit" name="submit" value="Sign in" class="btn btn-primary btn-block">
            </form>

            <div class="text-center mt-4 pb-1" style="border-bottom: 0.0625rem solid #dbdbdb">
              <a href="<?php echo route('getRegister'); ?>" class="font-size-xs">New account</a>
            </div>

            <div class="text-center pt-1">
              <a href="<?php echo route('password.request'); ?>" class="font-size-xs">Forgot password</a>
            </div>

          </div>	<!-- /.login-content -->
        </div> <!-- /.col-md-7 -->
      </div> <!-- /.row -->
    </div> <!-- /.container -->
  </section>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="<?php echo URL::to('js/parsley.min.js'); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.partials._simple_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>