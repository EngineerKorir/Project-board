<section id="share">
  <div class="hmi-buttons">
    <div class="btn-group btn-group-sm" role="group" aria-label="Button group with nested dropdown">
      <div class="btn-group btn-group-sm" role="group">
        <button id="btnSave" type="button" class="btn btn-secondary borderless-btn btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="Save">
          <i class="fa fa-bookmark glyph-r-margin"></i>
        </button>
        <div class="dropdown-menu" aria-labelledby="btnSave">
          <a class="dropdown-item" href="#">Save</a>
          <a class="dropdown-item" href="#">Reminder</a>
        </div>
      </div>

      <form class="" action="<?php echo e(route('postNoticeLike', ['id' => $notice->id])); ?>" method="POST" id="postNoticeLike">
        <?php echo e(csrf_field()); ?>

      </form>

      <button onclick="document.getElementById('postNoticeLike').submit();" class="btn btn-secondary borderless-btn btn-sm" title="Like">
        <i class="

        <?php if($isLikeNotice === 1): ?>
          fa fa-heart text-info
        <?php else: ?>
            fa fa-heart
        <?php endif; ?>
          glyph-r-margin

        "></i><?php echo e($likeShare['like']); ?></button>

      <button type="button" class="btn btn-secondary borderless-btn btn-sm" title="Comments"><i class="fa fa-comment glyph-r-margin"></i><?php echo e($totalComments); ?></button>

      <button type="button" class="btn btn-secondary borderless-btn btn-sm" title="Attachments"><i class="fa fa-paperclip text-muted glyph-r-margin glyph-l-margin"></i><?php echo e($totalAttachments); ?></button>

      <div class="btn-group btn-group-sm" role="group">
        <button id="btnShare" type="button" class="btn btn-secondary borderless-btn btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="Share">
          <i class="fa fa-share-alt glyph-r-margin"></i><?php echo e($likeShare['share']); ?>

        </button>

        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="btnShare">

          <form class="" action="<?php echo e(route('postNoticeShare', ['id' => $notice->id, 'to' => 'whatsapp'])); ?>" method="POST" id="postNoticeShareWhatsapp">
            <?php echo e(csrf_field()); ?>

          </form>

          <form class="" action="<?php echo e(route('postNoticeShare', ['id' => $notice->id, 'to' => 'timeline'])); ?>" method="POST" id="postNoticeShareTimeline">
            <?php echo e(csrf_field()); ?>

          </form>

          <a onclick="document.getElementById('postNoticeShareWhatsapp').submit();" class="dropdown-item" href="#"><i class="fa fa-whatsapp glyph-r-margin"></i>WhatsApp</a>

          <a onclick="document.getElementById('postNoticeShareTimeline').submit();" class="dropdown-item" href="#"><i class="fa fa-user glyph-r-margin"></i>Timeline</a>

        </div>
      </div>
    </div>
  </div> <!-- /.hmi-buttons -->
</section>
