<?php $__env->startSection('content'); ?>
<div class="header">
  <div id="burger-container" class="nav-trigger hidden-md-up">
    <div id="burger">
      <span>&nbsp;</span>
      <span>&nbsp;</span>
      <span>&nbsp;</span>
    </div><!-- /.burger -->
  </div> <!-- /.burger-container -->
  <div id="dash-head">
    <h3 class="pull-left"><?php echo $__env->yieldContent('dashboard-title'); ?></h3>
    <?php $__env->startSection('dashboard-header'); ?>
    <a class="btn btn-default btn-sm simple-btn" href="#"><i class="fa fa-edit glyph-r-margin"></i>New</a>
    <?php $__env->stopSection(); ?>
  </div> <!-- /.notice-head -->
</div>

<?php if($user): ?>

<?php if($user->role_id === 1): ?> 
    <?php echo $__env->make('layouts.partials._student-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php elseif($user->role_id === 2): ?> 
    <?php echo $__env->make('layouts.partials._department-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php elseif($user->role_id === 3): ?> 
    <?php echo $__env->make('layouts.partials._organization-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php elseif($user->role_id === 4): ?> 
    <?php echo $__env->make('layouts.partials._lecturer-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php elseif($user->role_id === 5): ?> 
    <?php echo $__env->make('layouts.partials._class-rep-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php else: ?>
    <?php echo $__env->make('layouts.partials._user-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php endif; ?>

<div id="main-content">
  <div class="container-fluid">
    <div class="row">
      <!-- Breadcrumb -->
      <ol class="breadcrumb hidden-xs-down">
        
        <?php echo $__env->yieldContent('breadcrumb'); ?>
      </ol>
      <!-- / Breadcrumb -->
    </div> <!-- /.row -->
    <?php echo $__env->yieldContent('dashboard-content'); ?>
  </div> <!-- /.container -->
</div> <!-- /.main-content -->

<?php $__env->stopSection(); ?> <!-- <?php $__env->startSection('content'); ?> -->

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.partials._simple_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
  $('.nav-trigger').click(function() {
    $('.side-nav').toggleClass('visible');
    $('.nav-trigger').toggleClass('open');
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>