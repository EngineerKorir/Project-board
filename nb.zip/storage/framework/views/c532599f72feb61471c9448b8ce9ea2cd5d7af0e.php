<?php $__env->startSection('dashboard-title'); ?>
View notice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard-header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="/profile/view" title="Profile">Profile</a></li>
<li class="breadcrumb-item active">View notice</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard-content'); ?>
<div class="row">
	<div class="col-md-9">
		<main>
			<section id="notice-view">

				<div class="card">
					<div class="card-header pt-3 bb-0">
						<h6><?php echo e($notice->title); ?></h6>
					</div>
					<div class="card-block">
						<?php echo $__env->make('layouts.partials.footers._author', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php echo $notice->body; ?>

					</div>
					<div class="card-footer pt-0 pb-0 bg-white bt-0">
						<?php echo $__env->make('layouts.partials.footers._share', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>

					<?php if($attachment): ?>
					<div class="card m-2">
					  <ul class="list-group list-group-flush">
							<?php $__currentLoopData = $attachment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="list-group-item font-size-xs">
								<i class="fa fa-paperclip mr-2"></i><a href="<?php echo e(URL::to('uploads/' . $name->name)); ?>"><?php echo e($name->name); ?></a>

								(

								<?php if( $name->size < 1024): ?>
								<?php echo e($name->size); ?> b

								<?php elseif($name->size >= 1024 &&  $name->size < 1048576 ): ?>
								<?php echo e(ceil($name->size/1024)); ?> kb

								<?php else: ?>

								<?php echo e(ceil($name->size/1048576)); ?> mb

								<?php endif; ?>
								)

							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </ul>
					</div>
					<?php endif; ?>
				</div>

			</section>
		</main>
		<div class="notice-comments">

			
			<?php echo $__env->make('layouts.partials._alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<?php if($totalComments > 0): ?>

			<section id="notice-comments">

				<h3 class="h6"><i class="fa fa-comments-o glyph-r-margin"></i> <?php echo e($totalComments); ?> Comments</h3>

				<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<article>
					<div class="notice-comments-item">
						<div class="card">
							<div class="card-block">
								<div class="card-header p-0 pb-1 pt-2 bb-0 mb-3 pl-1">
									<div class="notice-comments-avatar">

										<?php if($comment->user->photo): ?>
										<img src="<?php echo e(URL::to('images/avatars/small/' . $comment->user->photo)); ?>" alt="" title="" class="img-fluid" width="125">

										<?php else: ?>

										<img src="<?php echo e(URL::to('images/avatars/default/small/avatar.png')); ?>" alt="" title="" class="img-fluid">

										<?php endif; ?>
									</div>

									<div class="notice-comments-name">
										<h6><a href="#" class="<?php echo $comment->user->gender == 2 ? 'female' : ''; ?>"><?php echo e($comment->user->username); ?> </a><span class="notice-comments-dept glyph-r-margin">

											<?php if($comment->user->department): ?>

											<?php echo e($comment->user->department->name); ?>


											<?php elseif($comment->user->faculty): ?>

											<?php echo e($comment->user->faculty->name); ?>


											<?php endif; ?>

										</span> </h6>
									</div>
									<div class="notice-comments-datetime">
										<p><?php echo e($comment->created_at); ?></p>
									</div>
								</div><!-- /.card-header -->
								<div class="notice-comments-body">
									<?php echo $comment->text; ?>

								</div>
							</div>
							<div class="card-footer bg-white bt-0">
								<div class="notice-comments-footer">
									<?php echo $__env->make('layouts.partials.footers._share-comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</div>
							</div>
						</div>




					</div> <!-- /.notice-comments-item -->
				</article>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</section>

			<?php else: ?>

			<p class="text-center pt-5 pb-5">Be the first to leave a comment.</p>

			<?php endif; ?>

			<div class="notice-comments-box">
				<form class="" action="<?php echo e(route('postNoticeComment', ['noticeId' => $notice->id])); ?>" method="POST">
					<label for="text">Leave a comment</label>
					<textarea name="text" rows="3" class="form-control" placeholder="Your comment"><?php echo e(old('text')); ?></textarea>
					<input type="submit" class="btn btn-primary btn-sm mt-2" name="submit" value="Post">
					<?php echo csrf_field(); ?>

				</form>
			</div> <!-- /.notice-comments-box -->
		</div> <!-- /.notice-comments -->
	</div> <!-- /.col-md-9 -->
	<div class="col-md-3">
		<aside>
			<section id="notice-view-sidebar">
				<div class="notice-sidebar">
					<ul class="list-group">
						<li class="list-group-item justify-content-between">
							<div class="notice-sidebar-img">
								<?php if($notice->user->photo): ?>
								<img src="<?php echo e(URL::to('images/avatars/medium/' . $notice->user->photo)); ?>" alt="" title="" class="img-fluid" width="250">

								<?php else: ?>

								<img src="<?php echo e(URL::to('images/avatars/default/medium/avatar.png')); ?>" alt="" title="" class="img-fluid" width="250">

								<?php endif; ?>

							</div>
						</li>
						<li class="list-group-item justify-content-between">
							<?php if($notice->user->role_id === 2): ?> 

							<?php echo $notice->user->department->name .' '.$notice->user->username; ?>


							<?php elseif($notice->user->role_id === 4 && $notice->user->salutation_id !== 0): ?> 

							<?php echo $notice->user->salutation->name .'. '. $notice->user->username; ?>


							<?php else: ?> 

							<?php echo $notice->user->username; ?>


							<?php endif; ?>
						</li>
						<li class="list-group-item justify-content-between">
							Notices
							<span class="badge badge-default badge-pill"><?php echo e($totalNotices); ?></span>
						</li>
						<li class="list-group-item justify-content-between">
							Subscribers
							<span class="badge badge-default badge-pill"><?php echo e($totalSubscribers); ?></span>
						</li>
						<li class="list-group-item justify-content-between">
							<a class="btn btn-primary btn-sm mt-2 mb-2" href="#"><i class="fa fa-envelope-o glyph-r-margin"></i> Subscribe</a>
						</li>
					</ul>

				</div><!-- /.notice-sidebar -->
			</section>
		</aside>
	</div> <!-- /.col-md-3 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials._dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>