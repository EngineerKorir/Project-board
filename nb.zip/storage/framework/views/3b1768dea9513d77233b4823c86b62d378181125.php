<!-- jQuery -->
<script src="<?php echo URL::to('js/jquery-3.2.1.min.js'); ?>"></script>

<!-- Tether JS -->
<script src="<?php echo URL::to('js/tether.min.js'); ?>"></script>

<!-- Bootstrap JS-->
<script src="<?php echo URL::to('js/bootstrap.min.js'); ?>"></script>

<!-- Universal Custom JavaScript -->
<script src="<?php echo URL::to('js/custom.js'); ?>"></script>
<!-- Custom Javascript -->
<?php echo $__env->yieldContent('scripts'); ?>
